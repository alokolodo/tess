export default function MainView() {
    return <div className="main-view">Hello Redux</div>;
  }
  